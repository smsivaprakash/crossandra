package com.docstore.sample.test;

import java.util.List;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public class TestS3Services {
	
	public static void main(String[] args){
		AWSCredentials awsCredentials = new BasicAWSCredentials("AKIAIWOSXWNQUEYFMWQQ", "Y6GN+4xDQXKwqqJl1fi0mlXZcjYQeIC1JIDTyl4d");
		ClientConfiguration clientConfiguration = new ClientConfiguration();
		clientConfiguration.setProtocol(Protocol.HTTP);
		clientConfiguration.setProxyHost("proxy.cognizant.com");
		clientConfiguration.setProxyPort(6050);
		AmazonS3 s3client = new AmazonS3Client(awsCredentials, clientConfiguration);
		ObjectListing objectListing = s3client.listObjects(new ListObjectsRequest().withBucketName("testvaali"));
		List<S3ObjectSummary> objectSummaries = objectListing.getObjectSummaries();
		for(S3ObjectSummary summary : objectSummaries){
			System.out.println(summary.getKey()+"   "+summary.getSize());
		}
	}

}
